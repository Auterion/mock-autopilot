#pragma once

#ifdef __GNUC__
#pragma GCC system_header
#endif

#include "mavlink/v2.0/common/mavlink.h"
